$(document).ready(function(){
	$('h1').click(function(){
		$('p').hide();
	});
});